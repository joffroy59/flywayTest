create table ANIMAL (
    ID int not null,
    RACE varchar(100) not null
);