insert into ANIMAL (ID, RACE) values (1, 'Lion');
insert into ANIMAL (ID, RACE) values (2, 'Tiger');
insert into ANIMAL (ID, RACE) values (3, 'Eagle');
insert into ANIMAL (ID, RACE) values (4, 'Elephant');
